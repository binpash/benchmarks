Content of SIRV_Set1__Sequences_170612a (ZIP):

SIRV_isoforms_multi-fasta_170612a.fasta, multi-fasta files with individual lines for each of the 7 SIRV isoform gene sequences
SIRV_isoforms_multi-fasta-annotation_C_170612a.gtf, gtf file with correct annotations of SIRV isoform gene structures
SIRV_isoforms_multi-fasta-annotation_I_170612a.gtf, gtf file with insufficient annotations of SIRV isoform gene structures
SIRV_isoforms_multi-fasta-annotation_O_170612a.gtf, gtf file with over-annotations of SIRV isoform gene structures

SIRVome_isoforms_170612a.fasta, fasta file with all 7 SIRV isoform genes in one sequence, separated by 1000 Ns
SIRVome_isoforms_C_170612a, gtf file with correct annotations for SIRVome with isoform gene structures
SIRVome_isoforms_I_170612a, gtf file with insufficient annotations for SIRVome with isoform gene structures
SIRVome_isoforms_O_170612a, gtf file with over-annotations for SIRVome with isoform gene structures

